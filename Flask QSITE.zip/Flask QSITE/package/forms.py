# wtforms imports
from wtforms import StringField, PasswordField, SubmitField, BooleanField 
from wtforms import RadioField, FileField, SelectField,IntegerField # these are on 2nd line for easy visual
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError

# flask wtf
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed

# our own app imports
from package import db
from package.models import User
from flask_login import current_user
class isATC: # Reverse engineered from other validator class 
    def __init__(self, fieldname):
        self.fieldname = fieldname
        self.message = 'email not affiliated with ATC'

    def __call__(self,form, field):
        x = field.data.split('@') 
        if x[1] == 'atc.qld.edu.au':
            return 
        raise ValidationError(self.message)


class RegistrationForm(FlaskForm):
    username = StringField('Username',
                           validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email',
                        validators=[DataRequired(), Email(), isATC('email')])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('That username is taken. Please choose a different one.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        
        if user:
            raise ValidationError('That email is taken. Please choose a different one.')

class LoginForm(FlaskForm):
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')


class UpdateAccountForm(FlaskForm):
    username = StringField('New Username')
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    picture = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'png'])])
    submit = SubmitField('Update')
    # checks the username and the email to encourage safety of the app
    def validate_username(self, username):
        if username.data != current_user.username:
            user = User.query.filter_by(username=username.data).first()
            if user:
                raise ValidationError('That username is incorrect!')

    def validate_email(self, email):
        if email.data != current_user.email:
            user = User.query.filter_by(email=email.data).first()
            if user:
                raise ValidationError('That email is incorrect!')


class RatingForm(FlaskForm):
    options = ['Munster', 'Ulster', "Leinster", "Connacht"]
    choices = []
    for i in options:
        choices.append((i,i))
    result =  RadioField('Label', choices=choices) 
    submit = SubmitField('Submit Rating!')

class SearchForm(FlaskForm):
    house = StringField('Blog Title')
    poster = StringField('Blog Author')
    orderby = RadioField('Order By', choices=[('DESC','Decending'),('ASC','Ascending')])
    submit = SubmitField('Search')


class DeleteForm(FlaskForm):
    name = IntegerField()
    button = SubmitField('Delete')
