from flask import render_template, url_for, flash, redirect 
from package import app, db # our app and database 
from sqlalchemy import text # needed for newer versions of python allows extra checking of SQL
from flask_login import login_user, current_user, logout_user, login_required
from package.forms import RegistrationForm,LoginForm,UpdateAccountForm,RatingForm, DeleteForm,SearchForm  # our own forms
from package.models import User, Vote # Our own object for the user and voting tables in db
import os
from datetime import datetime
from PIL import Image
# This connects app to Database needs to be run once
# with app.app_context():
#     db.create_all()

# @app.route("/")
@app.route("/test")
def test():
    return '<html> <h> Hello World!</h></html>'

@app.route("/",methods=['POST','GET'])
@app.route("/home",methods=['POST','GET'])
def home():
    form = SearchForm()
    remove = DeleteForm()
    if form.validate_on_submit():
        
        if form.orderby.data != None:
            if form.house.data != None and form.house.data !='':
                rows = db.session.execute(text("SELECT * FROM vote WHERE vote LIKE'%"+form.house.data+"%' ORDER BY id "+form.orderby.data+";"))
            else:
                rows = db.session.execute(text("SELECT * FROM vote ORDER BY id "+ form.orderby.data+";"))
    else:
        rows = db.session.execute(text("SELECT * FROM vote"))            
    max_data = db.session.execute(text("SELECT * FROM (select vote, count(*)from vote group by vote order by vote DESC)")).first()
    if max_data:
        max = max_data[0]
        count = db.session.execute(text("SELECT COUNT(*) FROM vote WHERE vote = '"+ max+"';")).first()[0]
    else:
        max = 'No House'
        count = 0
    return render_template('home.html',  max = max, rows = rows, count = count, form = form, remove = remove)



@app.route("/about")
def about():
    return render_template('about.html', title='About')

@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = RegistrationForm()
    # Check if the user or email exists has been done in forms!
    if form.validate_on_submit():
        # Creates a user object
        user = User(username=form.username.data, email=form.email.data, password=form.password.data) 
        # adds the user 
        db.session.add(user)
        #commits it to the database
        db.session.commit()
        flash(f'Account created for {form.username.data}!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    elif form.validate_on_submit():
        #sqlalchemy select query 
        user =  User.query.filter_by(email=form.email.data).first()
        # alternative 
        db.session.execute(text(f"SELECT * FROM user WHERE email = '{form.email.data}'"))
        #checks if user exists        
        if user:
            # if the username and password are correct
            if form.email.data == user.email and form.password.data == user.password:
                #lets us have the site remember the user. And loggs them in
                login_user(user, remember= form.remember.data)
                
                flash('You have been logged in!' +str(current_user), 'success')   
                return redirect(url_for('account'))
            #username exists but password is wrong    
            else:
                flash('Login Unsuccessful. Incorrect password', 'danger')
        else:
            #username does not exist
            flash('Login Unsuccessful. Please check username and password or register an account!', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route("/logout", methods=['GET', 'POST'])
def logout():
    logout_user()
    return redirect(url_for('home'))

def save_picture(form_picture):
    # optional code to stop multiple files with the same name
    '''
    # changes the file name to an 8 bit hex code
    random_hex = secrets.token_hex(8)
    # Splits the file name into the file and then the file extension we don't store the fname
    _, f_ext = os.path.splitext(form_picture.filename) # _ makes a empty variable
    # rebuilds the picture file name
    picture_fn = random_hex + f_ext
    '''
    picture_fn = form_picture.filename
    # joins the file name to be saved to the correct path in static folder
    picture_path = os.path.join(app.root_path, 'static/Media/Profiles/', picture_fn)
    #using Pillow to shrink the image so that it can load it faster
    output_size = (125, 125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    # saves the picture
    i.save(picture_path)
    return picture_fn


# Route to handle GET and POST requests for the '/account' endpoint
@app.route("/account", methods=['GET', 'POST'])
@login_required # only works if logged in
def account():
    # Create an instance of the UpdateAccountForm
    form = UpdateAccountForm()
    # Get the URL for the user's profile image
    user_image = url_for('static', filename=f'/Media/Profiles/{current_user.image_file}')
    # Check if the form is submitted and valid
    if form.validate_on_submit():
        # Check if the user email is correct
        if current_user.email == form.email.data:
            if form.username.data != '' and 2 < len(form.username.data) < 20:
                # Update the username if it meets the length criteria
                new_username = form.username.data
                # Check if the new username is available
                username = db.session.execute(
                    "SELECT * FROM user WHERE username = '" + new_username +
                    "' AND id <> " + str(current_user.id) + ";").first()
                if not username:
                    db.session.execute(text("UPDATE user SET username = '" + new_username +
                                       "' WHERE username = '" + current_user.username + "';"))
                    db.session.commit()
                    flash('Your account has been updated!', 'success')
                    return redirect(url_for('account'))
                else:
                    flash('Username already taken!', 'danger')
            else:
                flash('Username needs to be between 2 and 20 characters!', 'danger')
        # Check if a new profile picture is provided
        if form.picture.data:
            # Save the new profile picture and update the user's image file
            picture_file = save_picture(form.picture.data)
            new_image = picture_file
            current_user.image_file = picture_file
            db.session.execute(text("UPDATE user SET image_file = '" + new_image +
                               "' WHERE username = '" + current_user.username + "';"))
            db.session.commit()
            flash('Your account has been updated!', 'success')
            return redirect(url_for('account'))
    # Render the account.html template with the user's image and the form
    return render_template('account.html', user_image=user_image, form=form)


@app.route("/vote", methods=['GET', 'POST'])
def vote():
    form = RatingForm()
    if form.validate_on_submit():
        date = datetime.utcnow().ctime()
        flash("you chose"+form.result.data,'sucess')
        vote = db.session.execute(text("SELECT username from vote where username = '"+
        current_user.username+"';")).first()
        
        if vote :
            
            db.session.execute(text("UPDATE vote SET date_posted = '"+date+"', vote = '"+
            form.result.data+"' WHERE username = '"+current_user.username+"';"))
            
            flash(str(current_user.username)+'Your vote has been updated' , 'success')
            db.session.commit()
        else:
            db.session.execute( text("INSERT INTO vote (vote,username,date_posted) VALUES ('"+
             form.result.data+"','"+current_user.username+"','"+date+"');"))
            db.session.commit()
            flash(str(current_user.username)+'You have voted!' , 'success')
    return render_template('vote.html',form = form)


# adds a route to the deletevote as well as setting up an indivdual page for the ID 
@app.route("/deletevote/<int:id>", methods=['GET', 'POST'])
def deletevote(id): # <data type : variable> 
    
    db.session.execute(text("DELETE from vote WHERE vote.id ="+ str(id) +";" ))
    
    db.session.commit()
    return redirect(url_for('home'))