from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# basic boilerplate
app = Flask(__name__) # initialises app
app.config["SECRET_KEY"] = "5791628bb0b13ce0c676dfde280ba245" # allows hidden form in WTF forms
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///site.db" # Creates a database address. 
#app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
# builds database object for application
db = SQLAlchemy(app) 
# builds a login manager for the app
login_manager = LoginManager(app)


    
from package import routes # runs the routes file which is the main controler 
# This is run last to stop circular import