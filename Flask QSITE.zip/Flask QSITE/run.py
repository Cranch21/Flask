from package import app 

# Hit play if you want your app to work!
if __name__ == "__main__":
    app.run(debug=True)